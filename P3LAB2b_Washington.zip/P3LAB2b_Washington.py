#CTI-110
#P3Lab2
#Xavier Washington
#10/8/21
#A program designed to write my initials (XW)
#



import turtle #Imports turtle module
wn = turtle.Screen() #Enables sandbox
wn.bgcolor("lightblue") #Hey, I like light green, why not use it as a background?

initial = turtle.Turtle() #Names the turtle
initial.color("blue") #Gives the penstroke color
initial.pensize(5) #Enlarges the stroke size


initial.right(50) #Start of code for letter 'X'
initial.forward(100)
initial.left(100)
initial.forward(100)
initial.backward(200) #Unknowngly discovered the backward code
initial.forward(100)
initial.right(100)
initial.forward(100)
initial.penup()
initial.left(50)
initial.forward(50) #End of code for letter 'X'

initial.pendown() #Puts my pen down to allow for spacing
initial.right(50)#Start of code for letter 'W'
initial.forward(100)
initial.left(100)
initial.forward(100)
initial.right(100)
initial.forward(100)
initial.left(100)
initial.forward(100)#End of code for letter 'W'
