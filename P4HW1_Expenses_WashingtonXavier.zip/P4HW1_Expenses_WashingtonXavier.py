# CTI-110
# P4HW1 - Expenses
# Xavier Washington
# 10/14/21
#
expense_count = 1 #This number increases whenever the user wants to input another expense.
continue_app = 'y' #For every 'y' input, the program keeps going.
start_amount = int(input('Enter starting amount in account:'))#This prompt asks the user for the starting amount of money in their account.
total = start_amount
print()
while continue_app == 'y' or continue_app == 'Y': #Start of 'continue app' code. This entire code executes the program, and keeps up with the 'y' or 'n' choices of the user.
    expense = int(input(f'Enter expense {expense_count}: '))
    total -= expense    
    continue_app = input('Do you want to enter another expense? (y/n):') #This prompt asks users if they'd like to enter another expense. Y/y means yes, N/n means no.
    if continue_app == 'y' or continue_app == 'Y':
        expense_count += 1 #End of 'continue app' code.


print()
print(f'Amount in account before expenses subtracted: ${start_amount}') #This prints the starting amount of funds
print(f'Number of expenses entered: {expense_count}') #This calculates & outputs the number of expenses that were user-entered
print(f'Amountn in account After expenses subtracted is: ${total}') #This subtracts all expenses from the starting amount.
