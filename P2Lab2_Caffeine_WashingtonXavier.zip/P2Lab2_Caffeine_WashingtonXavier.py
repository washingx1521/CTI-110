# A program designed to determine the half-life of however many mg of caffeine after 6, 12, and 24 hours.
# 9/29/21
# CTI-110 P2Lab2 - Module 4
# Xavier Washington
#

caffeine_mg = float(input('Enter milligram amount here:'))

mg_Two = (caffeine_mg / 2)#This equation represents the half life of caffeine after 6 hours#
mg_Three = (mg_Two / 2) #This equation represents the half life of caffeine after 12 hours#
mg_Four = (mg_Three / 2) #This equation represents the half life of caffeine after 24 hours#

txt='After 6 hours: {:.2f} mg' #This txt prints mg_Two, according to the input of caffeine_mg#
print(txt.format(mg_Two))
txt='After 12 hours: {:.2f} mg' #This txt prints mg_Three, according to the input of caffeine_mg#
print(txt.format(mg_Three))
txt='After 24 hours: {:.2f} mg' #This txt prints mg_Four, according to the input of caffeine_mg#
print(txt.format(mg_Four))
