#CTI-110
#P3HW1-Debugging
#Xavier Washington
#10/8/21
#A program designed to inform users of their letter grade based on a user-given number grade
#


def main():
    # This program takes a number grade and outputs a letter grade.

    # system uses 10-point grading scale
    A_score = 90
    B_score = 80
    C_score = 70
    D_score = 60
    F_score = 50
    # Anything below a 50 will be graded with a letter of 'F', and an automatic fail

    
    score = int(input('Enter grade: '))

    if score >= A_score: #A_score is the top of the list, no need for an 'and'
        print('Your grade is: A')
    else:
        
        if score >= B_score and score < A_score: #The 'and' serves as a range for the grading scale
            print('Your grade is: B')
        else:
            
            if score >= C_score and score < B_score: #A C is no greater than 79, no less than 70
                print('Your grade is: C')
            else:
            
                if score >= D_score and score < C_score:# A D is no greater than 69, no less than 60
                    print('Your grade is: D')
                else:

                    if score >= F_score and score < D_score: #An F is no greater than 59, all the way down to 0
                        print('Your grade is: F')
                    else:
                        print('Your grade is : F, Fail')# Any integer below 50 generates a 'Fail' along with the letter grade
                    







#Program starts here
main()
