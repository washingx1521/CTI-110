#CTI-110
#P3Lab1 - Interstate
#Xavier Washington
#10/5/2021
#

highway_number = int(input('Enter Interstate Number here:'))
primary_number = highway_number%100

if highway_number <1 or highway_number >999 or (highway_number%100) ==0:
    print('Not a valid interstate highway number.')
    
if highway_number <= 99:
    if (highway_number%2)== 0:
        print('I-',highway_number, 'is primary, going east/west')
    else:
        print('2')
else:

    if (highway_number%2) == 0:
        print('I-',highway_number, 'is Auxiliary, serving I-',primary_number,'going east/west.')
    else:
        print('I-',highway_number, 'is Auxiliary, serving I-',primary_number,'going north/south.')


    #print('I-',highway_number, 'is Auxiliary, going east/west.')
    

###elif highway_number >= 100 and highway_number <= 999:
##    if highway_number >99:
##        primary_number = highway_number%100
##    else:
##        primary_number = highway_number
