#CTI-110
#P3Lab2
#Xavier Washington
#10/8/21
#A program designed to make an overlapping triangle and square
#



import turtle #Imports turtle module
wn = turtle.Screen() #Enables sandbox
wn.bgcolor("lightblue") #Hey, I like light blue, why not use it as a background?
xavier = turtle.Turtle() #Names the turtle


xavier.forward(100)#Start of Square Code
xavier.right(90)
xavier.forward(100)
xavier.right(90)
xavier.forward(100)
xavier.right(90)
xavier.forward(100)#End of Square Code

xavier.penup()#Start of Triangle Code
xavier.right(200)
xavier.pendown()
xavier.forward(200)
xavier.right(200)
xavier.forward(200)
xavier.left(100)
xavier.forward(75)#End of Triangle Code

for turtle.Turtle in xavier:
    if xavier == "turtle.Turtle()":
        continue

