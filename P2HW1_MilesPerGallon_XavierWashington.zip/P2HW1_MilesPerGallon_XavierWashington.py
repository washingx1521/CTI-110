# A simple program designed to calculate the number of miles per gallon of gas, the cost per gallon, and the total cost per driven mile(s).
# 9/30/21
# CTI-110 P2HW1 - Miles Per Gallon
# Xavier Washington
#



milesDriven =int(input('Enter miles driven:')) #This is an input spot for users to enter the number of miles they've driven#
gallonsUsed =int(input('Enter gallons used:')) #This is an input spot for users to enter the number of gallons their vehicle has used#
costOfGallon =float(input('Enter cost per gallon:')) #This is an input spot for users to enter the cost per gallon of gas#

print()
txt='Miles Per Gallon: \t{:.2f}'
print(txt.format(milesDriven / gallonsUsed))
#This operation calculates Miles per gallon of gas

txt='Total Gas Cost: \t${:.2f}'
print(txt.format(costOfGallon * gallonsUsed))
#This operation calculates the cost of gas.

txt='Cost Per Mile: \t\t${:.2f}'
print(txt.format(costOfGallon / milesDriven))
#This operation calculates the cost of gas per miles driven
