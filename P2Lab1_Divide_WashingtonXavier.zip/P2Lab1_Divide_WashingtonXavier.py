# A simple program designed to divide user input by a value (x) a total of three times
# 9/28/21
# CTI-110 P2Lab1 - Module 4
# Xavier Washington
#
user_Num = int(input('Enter Integer to be divided: '))
x = int(input('Enter divisor: '))
user_Num2 = (user_Num // x)
user_Num3 = (user_Num2 // x)
user_Num4 = (user_Num3 // x)

print(user_Num2,user_Num3,user_Num4)
