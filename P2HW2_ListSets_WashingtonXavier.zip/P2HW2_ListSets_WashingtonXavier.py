#CTI-110
#P2HW2 - Lists and Sets
#Xavier Washington
#10/1/2021
#


num_1 = int(input('Enter num 1: '))
num_2 = int(input('Enter num 2: '))
num_3 = int(input('Enter num 3: '))
num_4 = int(input('Enter num 4: '))
num_5 = int(input('Enter num 5: '))
num_6 = int(input('Enter num 6: '))
num_sum = (num_1 + num_2 + num_3 + num_4 + num_5 + num_6)

number_list = [num_1, num_2, num_3, num_4, num_5, num_6]
print()
print('Created List')
print(number_list)

txt='Smallest number in list: {:.1f}'
print(txt.format(min(number_list)))

txt='Largest number  in list: {:.1f}'
print(txt.format(max(number_list)))

txt='Sum of numbers in List: {:.1f}'
print(txt.format(num_1 + num_2 + num_3 + num_4 + num_5 + num_6))

txt='Average of numbers in List: {:.1f}'
print(txt.format(num_sum / 6))

print()

number_list = [num_1, num_2, num_3, num_4, num_5, num_6]
number_set = set(number_list)

print('Created set')
print(number_set)
