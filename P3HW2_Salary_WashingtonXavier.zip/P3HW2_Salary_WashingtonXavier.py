#CTI-110
#P3HW2
#Xavier Washington
#10/7/2021
#A program designed to calculate an employee's working hours, pay rate, overtime hours, regular oay, and their total pay
#

employee_Name = (input('Enter employee name:'))
hours_Worked = int(input('Enter number of hours worked:'))
pay_Rate = float(input('Enter employee pay rate:'))
over_time = (hours_Worked - 40)
reg_pay = (pay_Rate * 40)

if hours_Worked >40:
    print(over_time)
elif hours_Worked >=40:
    over_time = 0
overtime_pay = ((pay_Rate * 1.5) * over_time)
gross_pay = (reg_pay + overtime_pay)
print('Employee name: ', employee_Name)
print()

print('Hours Worked\tPay Rate\tOvertime\tOvertime Pay\tRegHour\t\tGross')
print('--------------------------------------------------------------------------------------')
text = f'{hours_Worked}\t\t${pay_Rate}\t\t{over_time}\t\t${overtime_pay}\t\t${reg_pay}\t\t${gross_pay}'
print(text)
